"""
app/services/taf/taxonomy_mapper.py
=====================================
KPMG Trusted AI Framework (TAF) taxonomy mapping engine.

For all 133 taxonomy controls (every AI category — not just the detected one),
computes:
  - computed_status: Covered | Partial | Not Covered | Training Unlocked | N/A
  - score: live numeric score pulled from probe results or principle scores
  - evidence: human-readable string citing the source of the score

Score extraction priority per control:
  1. Blackbox probe pass-rate for that pillar (category_scores from summary)
  2. TAF principle score from evaluate report (trusted_ai_principles)
  3. Training data metric (for training-gated controls with uploaded data)
  4. None (shown as — in UI)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ── Load taxonomy JSON ─────────────────────────────────────────────────────────
_TAXONOMY_PATH = Path(__file__).parent.parent.parent / "config" / "taf_taxonomy.json"

def _load_taxonomy() -> List[Dict]:
    with open(_TAXONOMY_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

TAXONOMY: List[Dict] = _load_taxonomy()

# ── model_type → TAF category ──────────────────────────────────────────────────
_MODEL_TYPE_TO_CATEGORY: Dict[str, str] = {
    "general_llm":   "GAI",
    "rag":           "GAI",
    "summarization": "GAI",
    "classification":"PAI",
    "automation":    "DM",
}

def detect_ai_category(model_type: str) -> str:
    return _MODEL_TYPE_TO_CATEGORY.get((model_type or "").lower(), "GAI")


# ── category → full name (derived from the taxonomy itself) ────────────────────
_CATEGORY_FULL: Dict[str, str] = {row["category"]: row["category_full"] for row in TAXONOMY}


# ── Pillar → probe category aliases ───────────────────────────────────────────
# Blackbox probes use these category strings; map TAF pillar names to them.
_PILLAR_TO_PROBE_CAT: Dict[str, List[str]] = {
    "Fairness":       ["Fairness", "Fair", "Bias", "Equity"],
    "Explainability": ["Explainability", "Explain", "Transparency", "Reasoning"],
    "Data Integrity": ["Data Integrity", "Accuracy", "Accuracy/Hallucination", "Hallucination", "Groundedness"],
    "Security":       ["Security", "Robustness", "Adversarial", "Injection"],
    "Privacy":        ["Privacy", "Data Privacy", "PII"],
    "Transparency":   ["Transparency", "Disclosure", "Identity"],
    "Accountability": ["Accountability", "Governance", "Oversight"],
    "Reliability":    ["Reliability", "Consistency", "Stability"],
    "Safety":         ["Safety", "Harm", "Content Safety", "Violence"],
    "Sustainability": ["Sustainability", "Environmental", "Energy"],
}

# ── Pillar → principle key aliases ────────────────────────────────────────────
# trusted_ai_principles dict uses these exact keys (from base_evaluator PRINCIPLE_ORDER)
_PILLAR_TO_PRINCIPLE_KEY: Dict[str, str] = {
    "Fairness":       "Fairness",
    "Explainability": "Explainability",
    "Data Integrity": "Data Integrity",
    "Security":       "Security",
    "Privacy":        "Privacy",
    "Transparency":   "Transparency",
    "Accountability": "Accountability",
    "Reliability":    "Reliability",
    "Safety":         "Safety",
    "Sustainability":  "Sustainability",
}


# ── Score extractors ───────────────────────────────────────────────────────────

def _probe_score_for_pillar(
    probe_results: List[Dict],
    category_scores: Dict[str, Any],
    pillar: str,
) -> Optional[float]:
    """
    Extract pass-rate for a pillar from:
    1. category_scores dict (from blackbox summary.category_scores) — preferred
    2. Raw probe_results list — fallback
    """
    # 1. category_scores (pre-aggregated by orchestrator)
    if category_scores:
        aliases = _PILLAR_TO_PROBE_CAT.get(pillar, [pillar])
        for alias in aliases:
            # Try exact, then case-insensitive
            for key in category_scores:
                if alias.lower() == key.lower():
                    val = category_scores[key]
                    if isinstance(val, dict):
                        score = val.get("pass_rate") or val.get("score") or val.get("pct")
                        if score is not None:
                            return round(float(score) * (100 if float(score) <= 1 else 1), 1)
                    elif isinstance(val, (int, float)):
                        v = float(val)
                        return round(v * 100 if v <= 1 else v, 1)

    # 2. Raw probe list
    if not probe_results:
        return None
    aliases = _PILLAR_TO_PROBE_CAT.get(pillar, [pillar])
    relevant = [
        p for p in probe_results
        if any(a.lower() in str(p.get("category", "")).lower() for a in aliases)
    ]
    if not relevant:
        return None
    passed = sum(1 for p in relevant if p.get("passed", False))
    return round(passed / len(relevant) * 100, 1)


def _principle_score_for_pillar(principles: Dict, pillar: str) -> Optional[float]:
    """Extract score from trusted_ai_principles for a given pillar."""
    if not principles:
        return None
    key = _PILLAR_TO_PRINCIPLE_KEY.get(pillar, pillar)
    # Exact match
    if key in principles:
        val = principles[key]
        if isinstance(val, dict):
            return val.get("score")
        return float(val) if val is not None else None
    # Fuzzy match
    for pkey, pval in principles.items():
        if key.lower() in pkey.lower() or pkey.lower() in key.lower():
            if isinstance(pval, dict):
                return pval.get("score")
            return float(pval) if pval is not None else None
    return None


def _best_score(
    probe_results: List[Dict],
    category_scores: Dict,
    principles: Dict,
    pillar: str,
) -> Optional[float]:
    """Return the best available score for this pillar from any source."""
    s = _probe_score_for_pillar(probe_results, category_scores, pillar)
    if s is not None:
        return s
    return _principle_score_for_pillar(principles, pillar)


def _source_label(
    probe_results: List[Dict],
    category_scores: Dict,
    principles: Dict,
    pillar: str,
) -> str:
    """Return a short string describing where the score came from."""
    s = _probe_score_for_pillar(probe_results, category_scores, pillar)
    if s is not None:
        return "Blackbox probe pass-rate"
    s2 = _principle_score_for_pillar(principles, pillar)
    if s2 is not None:
        return "Governance evaluation score"
    return ""


# ── Training data metric extractor ─────────────────────────────────────────────
_TRAINING_METRIC_MAP: Dict[str, str] = {
    # representation / bias controls
    "GAI.FAIR.04": "representation_score",
    "GAI.FAIR.05": "representation_score",
    "PAI.FAIR.01": "representation_score",
    # explainability via training delta
    "GAI.EXP.04":  "deduplication_rate",
    # data integrity
    "GAI.DI.04":   "deduplication_rate",
    # security / membership inference
    "GAI.SEC.04":  "_pii_inverse",
    "PAI.SEC.02":  "_pii_inverse",
    # privacy
    "GAI.PRI.04":  "_pii_inverse",
    "GAI.PRI.05":  "_pii_inverse",
    "PAI.PRI.01":  "_pii_inverse",
    # reliability
    "GAI.REL.05":  "deduplication_rate",
    # sustainability / compute
    "GAI.SUS.04":  "_compute_score",
    "GAI.SUS.05":  "_compute_score",
    "PAI.SUS.01":  "_compute_score",
    "DM.SUS.01":   "_compute_score",
    "DP.SUS.01":   "_compute_score",
}

def _extract_training_metric(numbered_id: str, ta: Dict) -> Optional[float]:
    metric_key = _TRAINING_METRIC_MAP.get(numbered_id)
    if not metric_key:
        return None
    if metric_key == "_compute_score":
        size = ta.get("compute_size_proxy", "medium")
        return {"small": 85.0, "medium": 62.0, "large": 38.0}.get(str(size), 55.0)
    if metric_key == "_pii_inverse":
        pii = ta.get("pii_exposure_rate")
        if pii is None:
            return None
        # Lower PII rate = better score
        return round(max(0.0, 100.0 - float(pii)), 1)
    return ta.get(metric_key)


# ── Build evidence string ──────────────────────────────────────────────────────
def _build_evidence(
    base_mapped:     str,
    computed_status: str,
    score:           Optional[float],
    source_label:    str,
    row:             Dict,
    training_analysis: Optional[Dict],
) -> Optional[str]:
    parts: List[str] = []

    if computed_status in ("Covered", "Partial"):
        if score is not None:
            parts.append(f"{source_label}: {score}%")
        conf_note = row.get("confidence_note") or ""
        if conf_note and computed_status == "Partial":
            parts.append(conf_note)
        where = row.get("where") or ""
        if where and where != "—" and where not in (parts[0] if parts else ""):
            parts.append(f"Measured via: {where}")

    elif computed_status == "Training Unlocked":
        ta = training_analysis or {}
        if score is not None:
            parts.append(f"Computed from training data: {score}%")
        parts.append(f"File: {ta.get('filename', 'uploaded training dataset')}")
        parts.append("Dev: heuristic proxies. Prod: Azure ML Responsible AI Dashboard.")

    elif computed_status == "Not Covered":
        req = row.get("data_required") or ""
        if req:
            parts.append(f"Requires: {req}")
        if row.get("training_gated"):
            parts.append("Upload fine-tuning data in audit pipeline to unlock.")

    return " | ".join(parts) if parts else None


# ── Main mapping function ──────────────────────────────────────────────────────
def compute_taf_mapping(
    audit_result:           Dict[str, Any],
    report_result:          Optional[Dict[str, Any]] = None,
    training_analysis:      Optional[Dict[str, Any]] = None,
    ai_category:            str = "GAI",
    control_scores:         Optional[Dict[str, Any]] = None,
    applicable_categories:  Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Compute TAF mapping for all applicable TAX categories.

    Parameters
    ----------
    audit_result            : blackbox_audits row
    report_result           : evaluate report row (trusted_ai_principles, etc.)
    training_analysis       : training_data_uploads.analysis (if uploaded)
    ai_category             : auto-detected primary category (GAI | PAI | DM | PD | DP)
    applicable_categories   : all categories that should be fully evaluated,
                              derived from the registration profile's
                              taf_applicable_categories field.  GAI is always
                              included.  Defaults to [ai_category] when not
                              provided (backward-compatible).

    Returns
    -------
    { rows, summary, pillar_breakdown, ai_category, has_training_data }
    """
    # Normalise applicable_categories: GAI always in, default to [ai_category]
    if not applicable_categories:
        applicable_categories = [ai_category]
    applicable_set: set = {"GAI"} | set(applicable_categories)
    # ── Unpack probe data ──────────────────────────────────────────────────────
    probe_results: List[Dict] = audit_result.get("probe_results", []) or []
    if isinstance(probe_results, str):
        try:   probe_results = json.loads(probe_results)
        except Exception: probe_results = []
    if not isinstance(probe_results, list):
        probe_results = []

    # category_scores lives inside audit_result.summary or audit_result.extra
    raw_summary = audit_result.get("summary") or {}
    if isinstance(raw_summary, str):
        try:   raw_summary = json.loads(raw_summary)
        except Exception: raw_summary = {}

    category_scores: Dict = (
        raw_summary.get("category_scores") or
        audit_result.get("category_scores") or
        {}
    )
    if isinstance(category_scores, str):
        try:   category_scores = json.loads(category_scores)
        except Exception: category_scores = {}

    # control_scores: per-TAF-control pass rates from taf_probe_bank
    control_scores: Dict = audit_result.get("control_scores") or {}
    if isinstance(control_scores, str):
        try:   control_scores = json.loads(control_scores)
        except Exception: control_scores = {}

    # ── Unpack principle scores ────────────────────────────────────────────────
    principles: Dict = {}
    if report_result:
        raw_p = report_result.get("trusted_ai_principles") or {}
        if isinstance(raw_p, str):
            try:   raw_p = json.loads(raw_p)
            except Exception: raw_p = {}
        principles = raw_p or {}

    has_training = bool(training_analysis)

    # ── Map each taxonomy row ──────────────────────────────────────────────────
    rows_out: List[Dict] = []

    for row in TAXONOMY:
        pillar         = row["pillar"]
        numbered_id    = row["numbered_id"]
        training_gated = row.get("training_gated", False)

        # ── Cross-category controls: surfaced but marked N/A when the control's
        # category is not in the set of categories applicable to this system.
        # GAI is always applicable; the user picks additional ones at registration.
        if row["category"] not in applicable_set:
            applicable_names = ", ".join(
                f"{_CATEGORY_FULL.get(c, c)} ({c})" for c in sorted(applicable_set)
            )
            rows_out.append({
                "numbered_id":     numbered_id,
                "category":        row["category"],
                "category_full":   row["category_full"],
                "pillar":          pillar,
                "risk":            row["risk"],
                "test":            row.get("test"),
                "base_mapped":     row["mapped"],
                "computed_status": "N/A",
                "evidence":        None,
                "score":           None,
                "score_source":    None,
                "training_gated":  training_gated,
                "where":           row.get("where"),
                "data_required": (
                    f"Applies to {row['category_full']} ({row['category']}) AI systems only — "
                    f"this system is registered for: {applicable_names}."
                ),
                "confidence_note": row.get("confidence_note"),
            })
            continue

        base_mapped    = row["mapped"]          # Yes | Partial | No | N/A

        computed_status = base_mapped
        score: Optional[float] = None
        source_lbl = ""

        if base_mapped == "Yes":
            computed_status = "Covered"
            # Check for direct 1:1 control-level score first
            ctrl_data = control_scores.get(numbered_id)
            if ctrl_data:
                score = ctrl_data.get("pass_rate")
                source_lbl = f"TAF probe bank ({ctrl_data.get('passed',0)}/{ctrl_data.get('total',0)} probes passed)"
            else:
                score = _best_score(probe_results, category_scores, principles, pillar)
                source_lbl = _source_label(probe_results, category_scores, principles, pillar)

        elif base_mapped == "Partial":
            computed_status = "Partial"
            # Check for direct 1:1 control-level score first
            ctrl_data = control_scores.get(numbered_id)
            if ctrl_data:
                score = ctrl_data.get("pass_rate")
                source_lbl = f"TAF probe bank ({ctrl_data.get('passed',0)}/{ctrl_data.get('total',0)} probes passed)"
            else:
                score = _best_score(probe_results, category_scores, principles, pillar)
                source_lbl = _source_label(probe_results, category_scores, principles, pillar)

        elif base_mapped == "No":
            if training_gated and has_training:
                computed_status = "Training Unlocked"
                score = _extract_training_metric(numbered_id, training_analysis or {})
                source_lbl = "Training data analysis"
            else:
                computed_status = "Not Covered"

        elif base_mapped == "N/A":
            computed_status = "N/A"

        evidence = _build_evidence(
            base_mapped, computed_status, score, source_lbl, row, training_analysis
        )

        rows_out.append({
            "numbered_id":     numbered_id,
            "category":        row["category"],
            "category_full":   row["category_full"],
            "pillar":          pillar,
            "risk":            row["risk"],
            "test":            row.get("test"),
            "base_mapped":     base_mapped,
            "computed_status": computed_status,
            "evidence":        evidence,
            "score":           score,
            "score_source":    source_lbl or None,
            "training_gated":  training_gated,
            "where":           row.get("where"),
            "data_required":   row.get("data_required"),
            "confidence_note": row.get("confidence_note"),
        })

    # ── Summary counts ─────────────────────────────────────────────────────────
    covered_n   = sum(1 for r in rows_out if r["computed_status"] == "Covered")
    partial_n   = sum(1 for r in rows_out if r["computed_status"] == "Partial")
    no_n        = sum(1 for r in rows_out if r["computed_status"] == "Not Covered")
    unlocked_n  = sum(1 for r in rows_out if r["computed_status"] == "Training Unlocked")
    na_n        = sum(1 for r in rows_out if r["computed_status"] == "N/A")
    total_n     = len(rows_out)
    denom       = max(total_n - na_n, 1)
    coverage    = round((covered_n + partial_n * 0.5 + unlocked_n) / denom * 100, 1)

    summary = {
        "covered":           covered_n,
        "partial":           partial_n,
        "not_covered":       no_n,
        "training_unlocked": unlocked_n,
        "na":                na_n,
        "total":             total_n,
        "coverage_pct":      coverage,
    }

    # ── Pillar breakdown ───────────────────────────────────────────────────────
    pillars_seen = list(dict.fromkeys(r["pillar"] for r in rows_out))
    pillar_breakdown: Dict[str, Dict] = {}
    for p in pillars_seen:
        pr = [r for r in rows_out if r["pillar"] == p]
        # Aggregate score: weighted average of available scores
        scored = [r["score"] for r in pr if r["score"] is not None]
        agg_score = round(sum(scored) / len(scored), 1) if scored else None
        pillar_breakdown[p] = {
            "covered":           sum(1 for r in pr if r["computed_status"] == "Covered"),
            "partial":           sum(1 for r in pr if r["computed_status"] == "Partial"),
            "not_covered":       sum(1 for r in pr if r["computed_status"] == "Not Covered"),
            "training_unlocked": sum(1 for r in pr if r["computed_status"] == "Training Unlocked"),
            "na":                sum(1 for r in pr if r["computed_status"] == "N/A"),
            "total":             len(pr),
            "aggregate_score":   agg_score,
        }

    return {
        "ai_category":      ai_category,
        "rows":             rows_out,
        "summary":          summary,
        "pillar_breakdown": pillar_breakdown,
        "has_training_data": has_training,
    }


# ── Training data analysis (imported by taf_routes) ───────────────────────────
def analyse_training_data(df_records: List[Dict], filename: str) -> Dict[str, Any]:
    """
    Analyse uploaded training/fine-tuning data.
    Dev mode: heuristic proxies.
    Prod: Azure ML Responsible AI Dashboard + Azure Purview + fairlearn.
    """
    import statistics, re

    total = len(df_records)
    if total == 0:
        return {"filename": filename, "row_count": 0, "status": "empty"}

    # Label column detection
    label_col = next(
        (col for col in (df_records[0] or {}).keys()
         if any(k in col.lower() for k in ("label", "target", "class", "output", "y"))),
        None
    )

    label_dist: Dict[str, int] = {}
    if label_col:
        for rec in df_records:
            v = str(rec.get(label_col, ""))
            label_dist[v] = label_dist.get(v, 0) + 1

    representation_score: Optional[float] = None
    if label_dist and len(label_dist) >= 2:
        counts = list(label_dist.values())
        representation_score = round(min(counts) / max(max(counts), 1) * 100, 1)

    # Text length stats
    text_cols = [k for k in (df_records[0] or {}).keys()
                 if any(t in k.lower() for t in ("text", "input", "prompt", "content", "instruction"))]
    avg_len = len_variance = None
    if text_cols:
        lengths = [len(str(rec.get(text_cols[0], ""))) for rec in df_records]
        avg_len = round(statistics.mean(lengths), 1)
        if len(lengths) > 1:
            len_variance = round(statistics.stdev(lengths), 1)

    # Deduplication
    dedup_rate: Optional[float] = None
    if text_cols:
        unique_texts = len(set(str(rec.get(text_cols[0], "")) for rec in df_records))
        dedup_rate = round(unique_texts / max(total, 1) * 100, 1)

    # PII detection (regex heuristics)
    pii_patterns = [
        re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
        re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
        re.compile(r'\b(?:\d{4}[\s-]?){3}\d{4}\b'),
        re.compile(r'\b\d{10,11}\b'),
    ]
    sample_size = min(total, 200)
    pii_hits = sum(
        1 for rec in df_records[:sample_size]
        if any(p.search(" ".join(str(v) for v in rec.values())) for p in pii_patterns)
    )
    pii_rate = round(pii_hits / max(sample_size, 1) * 100, 1)

    compute_flag = "large" if total > 50_000 else "medium" if total > 5_000 else "small"

    return {
        "filename":              filename,
        "row_count":             total,
        "label_column":          label_col,
        "label_distribution":    label_dist,
        "representation_score":  representation_score,
        "avg_text_length":       avg_len,
        "text_length_variance":  len_variance,
        "deduplication_rate":    dedup_rate,
        "pii_exposure_rate":     pii_rate,
        "compute_size_proxy":    compute_flag,
        "status":                "analysed",
        "azure_note": (
            "Development mode: heuristic proxies. "
            "Production: Azure ML Responsible AI Dashboard, Azure Purview, fairlearn."
        ),
    }